// get elements
const list = document.querySelector(".todo-list");
const input = document.querySelector("#new-item-text");
const addButton = document.querySelector("#add-item");


// 1. EVENT DELEGATION (click on list)
list.addEventListener("click", function (event) {

    console.log(event.target.tagName);

    // click on LI → mark completed
    if (event.target.tagName === "LI") {
        event.target.classList.add("completed");
    }

    // click on SPAN → delete item
    if (event.target.tagName === "SPAN") {
        event.target.parentElement.remove();
    }
});


// 2. FUNCTION TO ADD NEW ITEM
function addItem() {

    const text = input.value;

    if (text === "") return;

    const li = document.createElement("li");
    li.classList.add("todo-item");
    li.textContent = text;

    const span = document.createElement("span");
    span.classList.add("remove");

    li.appendChild(span);
    list.appendChild(li);

    input.value = "";
}


// 3. CLICK "+" BUTTON
addButton.addEventListener("click", function (event) {
    event.preventDefault();
    console.log("Add button clicked");
    addItem();
});


// 4. PRESS ENTER KEY
input.addEventListener("keydown", function (event) {
    console.log("Key pressed");

    if (event.key === "Enter") {
        addItem();
    }
});