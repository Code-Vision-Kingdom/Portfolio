<!DOCTYPE>
<html>
<head>
    <title>Display Travel Blog Email Records</title>
    <style type = "text/css">
        body {text-align:center; background-color: rgb(255,255,255); }
        table.center {
            margin-left:auto;
            margin-right:auto;
        }
        tr,td {
            text-align:center;
        }
        h2 {
            text-align:center;
        }
    </style>
</head>
<body>

<?php
// Set the variable for the database access:
require_once('connectvars.php');
$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$query = "SELECT * from email_list";
$result = mysqli_query($dbc, $query);

//create a table
print ("<h2>Travel the world - contact list</h2>");
print ("<table class= 'center' border='1' width='75%' cellspacing='2' cellpadding='2'>");
print ("<tr>");
print ("<td><b>FIRST NAME</b></td>");
print ("<td><b>LAST NAME</b></td>");
print ("<td><b>EMAIL</b></td>");
print ("</tr>");

//Fetch the results from the database.
while ($Row = mysqli_fetch_array($result)){
    print("<article>");
    print("<img src= 'sea.jpg' alt = '$Row[first_name]' title = '$Row[first_name]'/>");
    print("<p>$Row[first_name]</p>");
    print("<p>Last Name: $Row[last_name]</p>");
    print("<p>Email: $Row[email]</p>");
    print("</article>");
}

mysqli_close($dbc);
print "</table>";
$currentDate = date("Y-m-d");
print ("<br /><p style=\"text-align: center;\"><em>Darius Cherry &nbsp; &nbsp; Date: $currentDate</em></p>");

?>
</body>
</html>
