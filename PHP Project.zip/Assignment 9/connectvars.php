<?php
mysqli_report(MYSQLI_REPORT_OFF);
// Define the database connection constants here!
define('DB_HOST', 'localhost');
define('DB_USER', 'w26aaj');
define('DB_PASSWORD', 'gm0uvgm0uv');
define('DB_NAME', 'w26aajdb');
?>
