<!DOCTYPE html>
<html>
<head>
    <title>Create MOVIES Table</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php
// Set the variables for the database access:
require_once('connectvars.php');

//Create table inside the database
$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
// Create the query to create the Movies table
$query = "CREATE TABLE IF NOT EXISTS email_list (
 id INT AUTO_INCREMENT,
 first_name VARCHAR(20) ,
 last_name VARCHAR(20) ,
 email VARCHAR(60) ,
 PRIMARY KEY (id)
 )";
$result = mysqli_query($dbc, $query);
if ($result) {
    echo "The query was successfully executed! Table Created! <br />";
} else {
    echo "The query could not be executed! Error: " . mysqli_error($dbc);
}

mysqli_close($dbc);
?>
</body>
</html>
